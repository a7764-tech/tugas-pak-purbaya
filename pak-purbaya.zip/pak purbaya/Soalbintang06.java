public class Soalbintang06 {

    public static void main(String[] args) {
        System.out.println("    *");
        System.out.println("   **");
        System.out.println("  ***");
        System.out.println("   *");
        System.out.println("  **");
        System.out.println(" ***");
    }
}